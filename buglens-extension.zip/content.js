const U=new Set(["password","email","tel","cc-number","cc-csc"]),O=new Set(["cc-number","cc-csc","cc-exp","cc-name"]);function Y(e){var n;return U.has(e.type.toLowerCase())||O.has(((n=e.autocomplete)==null?void 0:n.toLowerCase())??"")||e.hasAttribute("data-pii")||e.hasAttribute("data-sensitive")||e.classList.contains("pii")}function B(e){return e instanceof HTMLInputElement&&Y(e)?"[REDACTED]":e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement?e.value.slice(0,200):""}function X(e){var o,i;if(e.id){const r=document.querySelector(`label[for="${CSS.escape(e.id)}"]`);if((o=r==null?void 0:r.textContent)!=null&&o.trim())return r.textContent.trim()}const n=e.closest("label");if((i=n==null?void 0:n.textContent)!=null&&i.trim())return n.textContent.trim();const t=e.getAttribute("aria-label");return t||"placeholder"in e&&e.placeholder||null}function F(e){if(e===document.documentElement||e===document.body)return"Page";if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement||e instanceof HTMLSelectElement){const i=X(e);if(i)return i.slice(0,100)}const t=e.closest('button, a, [role="button"], [role="link"], summary, details')||e,o=t.getAttribute("aria-label")||t.getAttribute("title")||(t.innerText||"").trim();return o?(o.split(`
`)[0]??"").trim().slice(0,100)||`[${t.tagName.toLowerCase()}]`:`[${t.tagName.toLowerCase()}]`}function _(e){const n=[];let t=e;for(;t&&t!==document.body;){const o=t.id?`#${t.id}`:"",i=t.tagName.toLowerCase();if(n.unshift(o||i),o)break;t=t.parentElement}return n.join(" > ").slice(0,500)}function z(){return{pageUrl:window.location.href,pageTitle:document.title}}let l=!1,f=!1;const m=[],G=2e3,$=50;let g=window.location.href;const S=2e3,V=80;let p=null,d=null,y=0;function x(e){if(!e.isConnected)return!1;const n=window.getComputedStyle(e);if(n.display==="none"||n.visibility==="hidden"||n.opacity==="0")return!1;const t=e.getBoundingClientRect();return t.width>0&&t.height>0}function E(e,n,t){const o=F(n),i=_(n),r=B(n),{pageUrl:u,pageTitle:s}=z();return{eventId:crypto.randomUUID(),actionType:e,elementLabel:o,cssSelector:i,valueMasked:r,timestamp:new Date().toISOString(),pageUrl:u,pageTitle:s,viewportWidth:window.innerWidth,viewportHeight:window.innerHeight,...t}}function b(e,n=!1){const t=m[m.length-1];if(t&&t.actionType===e.actionType&&t.cssSelector===e.cssSelector&&e.actionType==="INPUT"){t.valueMasked=e.valueMasked,t.timestamp=e.timestamp;return}m.push(e),n&&chrome.runtime.sendMessage({type:"CAPTURE_STEP_SCREENSHOT",payload:{eventId:e.eventId,clickX:e.clickX,clickY:e.clickY,elementRect:e.elementRect}}).catch(()=>{}),m.length>=$&&h()}function W(e,n){if(!l||f||!x(e))return;const t=e.getBoundingClientRect(),o={x:t.left+window.scrollX,y:t.top+window.scrollY,width:t.width,height:t.height,scrollX:window.scrollX,scrollY:window.scrollY},i=E("CLICK",e,{clickX:n.clientX,clickY:n.clientY,elementRect:o}),r=Date.now();p&&r-p.timestamp<S&&p.cssSelector!==_(e)&&b(p.event,!1),p=null,d&&r-d.timestamp<S&&Math.abs(d.scrollY-y)>=V&&(b(d.event,!1),y=d.scrollY),d=null,b(i,!0)}function K(e){if(!l||f||!x(e))return;const n=E("INPUT",e);b(n,!1)}function T(e,n){if(!l||f)return;const t=E("NAVIGATE",document.documentElement,{fromUrl:e,toUrl:n,pageUrl:n,pageTitle:document.title});b(t,!1)}function h(){if(m.length===0)return;const e=m.splice(0,m.length);chrome.runtime.sendMessage({type:"EVENTS_BATCH",payload:e}).catch(n=>{console.error("[BugLens] Failed to flush events:",n),m.unshift(...e)})}function j(){const e=window.location.href;e!==g&&(T(g,e),g=e)}let w=null;function q(){w=setInterval(j,500)}function J(){w&&(clearInterval(w),w=null)}function L(e){if(e.target instanceof HTMLElement){const t=e.target.closest('button, a, [role="button"], [role="link"], input, select, textarea')||e.target;x(t)&&(ee(t),W(t,e))}}function I(e){e.target instanceof HTMLElement&&K(e.target)}function Q(e){if(!(!l||f)&&e.target instanceof HTMLElement){const n=e.target.closest('button, a, input, select, textarea, [role="button"]');if(!n)return;const t=n;if(!x(t))return;p={event:E("HOVER",t),cssSelector:_(t),timestamp:Date.now()}}}const k=H(e=>Q(e),500);function Z(){if(!l||f)return;const e=window.scrollY;d={event:E("SCROLL",document.documentElement,{scrollX:window.scrollX,scrollY:e}),scrollY:e,timestamp:Date.now(),baseScrollY:y}}const R=H(Z,300);function A(){const e=window.location.href;T(g,e),g=e}function ee(e){const n=e.getBoundingClientRect(),t=document.createElement("div");t.id="__bugbuddy_click_highlight__";const o=n.top+window.scrollY,i=n.left+window.scrollX;t.style.cssText=`
    position: absolute;
    top: ${o}px;
    left: ${i}px;
    width: ${n.width}px;
    height: ${n.height}px;
    border: 2.5px solid #7c4dff;
    background: rgba(124, 77, 255, 0.18);
    border-radius: 6px;
    pointer-events: none;
    z-index: 2147483646;
    transition: opacity 0.5s ease-out, transform 0.5s ease-out;
    box-shadow: 0 0 0 3px rgba(124, 77, 255, 0.25), 0 0 14px rgba(124, 77, 255, 0.5);
    box-sizing: border-box;
  `,document.body.appendChild(t),requestAnimationFrame(()=>{setTimeout(()=>{t.style.opacity="0",t.style.transform="scale(1.06)",setTimeout(()=>t.remove(),500)},400)})}function te(){const e=document.createElement("div");e.style.cssText=`
    position: fixed;
    inset: 0;
    background: rgba(255,255,255,0.35);
    z-index: 2147483647;
    pointer-events: none;
    animation: __bugbuddy_flash 0.35s ease-out forwards;
  `;const n=document.createElement("style");n.textContent=`
    @keyframes __bugbuddy_flash {
      0% { opacity: 1; }
      100% { opacity: 0; }
    }
  `,document.head.appendChild(n),document.body.appendChild(e),setTimeout(()=>{e.remove(),n.remove()},400),ne("📷 Screenshot captured")}function ne(e){const n=document.getElementById("__bugbuddy_toast__");n&&n.remove();const t=document.createElement("div");t.id="__bugbuddy_toast__",t.style.cssText=`
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: rgba(22, 22, 29, 0.95);
    color: #f1f0ff;
    padding: 10px 16px;
    border-radius: 8px;
    font-family: -apple-system, sans-serif;
    font-size: 13px;
    font-weight: 500;
    border: 1px solid rgba(124, 77, 255, 0.4);
    box-shadow: 0 4px 24px rgba(0,0,0,0.5);
    z-index: 2147483647;
    pointer-events: none;
    opacity: 1;
    transition: opacity 0.4s ease-out;
    display: flex;
    align-items: center;
    gap: 8px;
  `,t.textContent=e,document.body.appendChild(t),setTimeout(()=>{t.style.opacity="0",setTimeout(()=>t.remove(),400)},2e3)}let a=null;function P(){a||(a=document.createElement("div"),a.id="__bugbuddy_pause_banner__",a.style.cssText=`
    position: fixed; top: 0; left: 0; right: 0; z-index: 2147483647;
    background: #f59e0b; color: #1c1917; text-align: center;
    padding: 6px 12px; font-family: sans-serif; font-size: 13px; font-weight: 600;
    pointer-events: none;
  `,a.textContent="⏸ BugLens recording paused — Press Ctrl+Shift+P to resume",document.body.appendChild(a))}function M(){a==null||a.remove(),a=null}let c=null;function D(){if(c)return;c=document.createElement("div"),c.id="__bugbuddy_recording_banner__",c.style.cssText=`
    position: fixed; top: 0; right: 0; z-index: 2147483646;
    background: rgba(22,22,29,0.92); color: #f87171;
    padding: 6px 14px; font-family: -apple-system, sans-serif; font-size: 12px; font-weight: 600;
    pointer-events: none; border-bottom-left-radius: 8px;
    border: 1px solid rgba(239,68,68,0.3); border-top: none; border-right: none;
    display: flex; align-items: center; gap: 6px;
    backdrop-filter: blur(4px);
  `;const e=document.createElement("span");e.style.cssText=`
    width: 7px; height: 7px; border-radius: 50%; background: #ef4444;
    display: inline-block;
    animation: __bugbuddy_pulse 1.2s infinite;
  `;const n=document.createElement("style");n.textContent="@keyframes __bugbuddy_pulse { 0%,100%{opacity:1} 50%{opacity:0.3} }",document.head.appendChild(n),c.appendChild(e),c.appendChild(document.createTextNode("BugLens Recording · Ctrl+I to capture")),document.body.appendChild(c)}function C(){c==null||c.remove(),c=null}function N(e){l||(l=!0,g=window.location.href,y=window.scrollY,p=null,d=null,document.addEventListener("click",L,!0),document.addEventListener("input",I,!0),document.addEventListener("mouseover",k,!0),document.addEventListener("scroll",R,{passive:!0}),window.addEventListener("popstate",A),window.addEventListener("beforeunload",h),ie(),q(),D())}function oe(){l&&(l=!1,f=!1,p=null,d=null,h(),re(),J(),document.removeEventListener("click",L,!0),document.removeEventListener("input",I,!0),document.removeEventListener("mouseover",k,!0),document.removeEventListener("scroll",R),window.removeEventListener("popstate",A),window.removeEventListener("beforeunload",h),M(),C())}chrome.runtime.onMessage.addListener((e,n,t)=>{switch(e.type){case"START_RECORDING":{const{sid:o}=e.payload;N();break}case"STOP_RECORDING":{oe();break}case"PAUSE_RECORDING":{f=!0,h(),P(),C();break}case"RESUME_RECORDING":{f=!1,M(),l&&D();break}case"SCREENSHOT_FLASH":{te();break}case"CAPTURE_STORAGE":{const o={},i=r=>/(token|password|secret|key|auth|session)/i.test(r);try{const r={};for(let u=0;u<localStorage.length;u++){const s=localStorage.key(u);s&&(r[s]=i(s)?"[REDACTED]":localStorage.getItem(s))}o.localStorage=r}catch{o.localStorage="[ACCESS_DENIED]"}try{const r={};for(let u=0;u<sessionStorage.length;u++){const s=sessionStorage.key(u);s&&(r[s]=i(s)?"[REDACTED]":sessionStorage.getItem(s))}o.sessionStorage=r}catch{o.sessionStorage="[ACCESS_DENIED]"}t(o);return}}});let v=null;function ie(){v=setInterval(h,G)}function re(){v&&(clearInterval(v),v=null)}function H(e,n){let t=0;return o=>{const i=Date.now();i-t>=n&&(t=i,e(o))}}chrome.runtime.sendMessage({type:"GET_RECORDING_STATE"},e=>{e!=null&&e.sessionId&&(N(e.sessionId),e.isPaused&&(f=!0,P(),C()))});
