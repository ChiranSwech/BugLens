var Kt=Object.defineProperty;var Vt=(u,b,r)=>b in u?Kt(u,b,{enumerable:!0,configurable:!0,writable:!0,value:r}):u[b]=r;var at=(u,b,r)=>Vt(u,typeof b!="symbol"?b+"":b,r);import{r as o,j as e,R as Jt,a as Gt}from"./chunks/client-Bh-W1TDz.js";const nt=["#ef4444","#f59e0b","#10b981","#3b82f6","#a855f7","#ffffff"],rt={CLICK:"🖱️",INPUT:"⌨️",NAVIGATE:"🔗",SCROLL:"📜",HOVER:"👆"},qt={P0:"#ef4444",P1:"#f97316",P2:"#f59e0b",P3:"#3b82f6",P4:"#6b7280"};function Yt(u,b){const r=parseInt(u.slice(1,3),16),C=parseInt(u.slice(3,5),16),d=parseInt(u.slice(5,7),16);return`rgba(${r}, ${C}, ${d}, ${b})`}async function Xt(u,b=8e5,r=.72){return!u||typeof u!="string"||!u.startsWith("data:image/")?null:new Promise(C=>{const d=new Image,L=setTimeout(()=>C(u),2e3);d.onload=()=>{clearTimeout(L);try{const T=document.createElement("canvas");T.width=d.width,T.height=d.height;const ee=T.getContext("2d");if(!ee){C(u);return}ee.drawImage(d,0,0);const M=T.toDataURL("image/jpeg",r),te=Math.round(M.length*3/4);if(te>b){console.warn(`[BugBuddy] Screenshot too large after compression (${te} bytes), skipping`),C(null);return}C(M)}catch{C(u)}},d.onerror=()=>{clearTimeout(L),C(null)},d.src=u})}const Zt=u=>u?u.replace(/\s+(\d+\.)/g,`
$1`).split(`
`).map(r=>r.trim()).filter(Boolean).join(`
`):"",Qt=()=>{var et,tt,st;const[u,b]=o.useState("steps"),[r,C]=o.useState([]),[d,L]=o.useState({}),[T,ee]=o.useState([]),[M,te]=o.useState([]),[se,ot]=o.useState({}),[le,ce]=o.useState(null),[w,Ne]=o.useState(""),[F,Te]=o.useState(""),[N,Ie]=o.useState("P2"),[R,it]=o.useState(""),[A,lt]=o.useState(""),[$,$e]=o.useState(""),[B,Ee]=o.useState(""),[D,de]=o.useState(""),[y,pe]=o.useState(null),[W,ct]=o.useState(!0),[Le,Me]=o.useState(!1),[ge,Re]=o.useState(!1),[H,Ae]=o.useState(!1),[ts,dt]=o.useState(!1),[ze,z]=o.useState(null),[Ue,ue]=o.useState(!1),[Be,De]=o.useState("http://localhost:8080"),[K,pt]=o.useState(!1),[he,gt]=o.useState("Bug"),[V,ut]=o.useState(!1),[J,ht]=o.useState("#bugs"),[G,xt]=o.useState(!1),[xe,mt]=o.useState("Bug"),[ss,bt]=o.useState([]),[Oe,Pe]=o.useState(!1),[me,q]=o.useState(null),[Fe,_e]=o.useState(!1),[be,Y]=o.useState(null),[We,He]=o.useState(!1),[fe,X]=o.useState(null),[E,ft]=o.useState(null),[ye,Ke]=o.useState(!1),[Z,Ve]=o.useState(!1),[m,ae]=o.useState(0),[ne,yt]=o.useState(1),[ve,we]=o.useState(!1),[re,vt]=o.useState(null),[je,wt]=o.useState(null),[_,jt]=o.useState("rect"),[O,kt]=o.useState(nt[0]??"#ef4444"),j=o.useRef(null),Q=o.useRef(!1),f=o.useRef({x:0,y:0}),ke=o.useRef(null),U=o.useRef([]);o.useEffect(()=>{let t=null;if(Z&&r.length>0){const s=Math.max(200,1500/ne);t=setInterval(()=>{ae(a=>a>=r.length-1?(Ve(!1),a):a+1)},s)}return()=>{t&&clearInterval(t)}},[Z,ne,r.length]);const St=async()=>{Ke(!0),z(null);try{const t={steps,networkLogs:T.filter(a=>a.failed||a.status&&a.status>=400),consoleLogs:M.filter(a=>a.type==="error"||a.type==="exception"),bugUrl:$,testData:B},s=await chrome.runtime.sendMessage({type:"API_REQUEST",payload:{url:"/v1/ai/triage",options:{method:"POST",body:JSON.stringify(t)}}});s!=null&&s.data?ft(s.data):s!=null&&s.error&&z(s.error)}catch(t){z(t.message||"Triage analysis failed")}finally{Ke(!1)}},Ct=async()=>{if(r.length!==0){we(!0);try{const a=document.createElement("canvas");a.width=800,a.height=450;const n=a.getContext("2d"),c=a.captureStream(30),g=new MediaRecorder(c,{mimeType:"video/webm"}),h=[];g.ondataavailable=x=>{x.data.size>0&&h.push(x.data)},g.onstop=async()=>{const x=new Blob(h,{type:"video/webm"}),i=URL.createObjectURL(x),p=`session-recording-${Date.now()}.webm`;await chrome.downloads.download({url:i,filename:p,saveAs:!0}),URL.revokeObjectURL(i),we(!1)},g.start();for(let x=0;x<r.length;x++){const i=r[x],p=d[x];n.fillStyle="#090d16",n.fillRect(0,0,800,450),p&&await new Promise(v=>{const l=new Image;l.onload=()=>{const I=Math.min(800/l.width,390/l.height),P=(800-l.width*I)/2,Ht=50+(390-l.height*I)/2;n.drawImage(l,P,Ht,l.width*I,l.height*I),v()},l.onerror=()=>v(),l.src=p}),n.fillStyle="#111827",n.fillRect(0,0,800,46),n.strokeStyle="#374151",n.lineWidth=1,n.beginPath(),n.moveTo(0,46),n.lineTo(800,46),n.stroke(),n.fillStyle="#6366f1",n.beginPath(),n.arc(24,23,13,0,Math.PI*2),n.fill(),n.fillStyle="#ffffff",n.font="bold 12px sans-serif",n.textAlign="center",n.fillText(`${x+1}`,24,27),n.textAlign="left",n.fillStyle="#f9fafb",n.font="bold 13px sans-serif";const k=(i.actionType||"CLICK").toUpperCase(),S=i.elementLabel?` — ${i.elementLabel.slice(0,45)}`:"";n.fillText(`${k}${S}`,46,27),i.pageUrl&&(n.fillStyle="#9ca3af",n.font="11px sans-serif",n.textAlign="right",n.fillText(i.pageUrl.slice(0,40),784,27)),await new Promise(v=>setTimeout(v,1200))}g.stop()}catch(t){console.error("[BugBuddy] Export video error:",t),we(!1)}}},[Nt,Tt]=o.useState(""),[oe,It]=o.useState(!1),Se=o.useCallback(async()=>{var c,g;const t=await chrome.runtime.sendMessage({type:"GET_SESSION_EVENTS"});if(t!=null&&t.events){C(t.events),ce(t.sessionId);const h=new Map;t.events.forEach(i=>{if(i.actionType==="INPUT"&&i.valueMasked){const p=i.elementLabel||i.cssSelector||"Unknown Input";h.set(p,i)}});const x=Array.from(h.values());x.length>0&&Ee(i=>i||x.map(p=>`${p.elementLabel||"Input"}: ${p.valueMasked}`).join(`
`)),de(i=>i||t.events.map((p,k)=>{const S=p.elementLabel||"element",v=(p.actionType||"CLICK").toUpperCase();if(v==="CLICK")return`${k+1}. Click on the "${S}".`;if(v==="INPUT"){const l=p.valueMasked&&p.valueMasked!=="[REDACTED]"?` "${p.valueMasked}"`:"";return`${k+1}. Enter${l} in the "${S}" field.`}return v==="NAVIGATE"?`${k+1}. Navigate to the next page.`:v==="SCROLL"?`${k+1}. Scroll the page.`:v==="HOVER"?`${k+1}. Hover over "${S}".`:`${k+1}. Perform ${p.actionType||"action"} on "${S}".`}).join(`
`))}const s=await chrome.runtime.sendMessage({type:"GET_SCREENSHOTS"});s!=null&&s.screenshots&&L(s.screenshots);const a=await chrome.runtime.sendMessage({type:"GET_NETWORK_LOGS"});a!=null&&a.logs&&ee(a.logs);const n=await chrome.runtime.sendMessage({type:"GET_CONSOLE_LOGS"});n!=null&&n.logs&&te(n.logs);try{const h=await chrome.tabs.query({active:!0,currentWindow:!0});if((c=h[0])!=null&&c.id){const x=await chrome.tabs.sendMessage(h[0].id,{type:"CAPTURE_STORAGE"});x&&ot(x)}if((g=h[0])!=null&&g.url){const x=h[0].url;$e(i=>i||x)}}catch{}},[]);o.useEffect(()=>{Se(),chrome.storage.local.get(["customApiBase"],s=>{s.customApiBase&&De(s.customApiBase)});const t=s=>{s.type==="SCREENSHOT_TAKEN"&&L(a=>({...a,[s.payload.stepIndex]:s.payload.dataUrl})),s.type==="STEP_COUNT_UPDATED"&&Se()};return chrome.runtime.onMessage.addListener(t),()=>chrome.runtime.onMessage.removeListener(t)},[Se]);const Je=t=>{chrome.runtime.sendMessage({type:"DELETE_STEP",payload:{stepIndex:t}}).catch(()=>{}),C(s=>s.filter((a,n)=>n!==t)),L(s=>{const a={};return Object.entries(s).forEach(([n,c])=>{const g=Number(n);g!==t&&(a[g<t?g:g-1]=c)}),a}),pe(s=>s===null||s===t?null:s>t?s-1:s)},$t=()=>{const t=Be.trim().replace(/\/$/,"");chrome.storage.local.set({customApiBase:t||"http://localhost:8080"},()=>{ue(!1),z(null)})},Et=async t=>{const s=await chrome.runtime.sendMessage({type:"CAPTURE_SCREENSHOT",payload:{stepIndex:t}});s!=null&&s.dataUrl&&L(a=>({...a,[s.stepIndex]:s.dataUrl}))},Lt=t=>{const s=d[t];s&&(wt(t),vt(s),b("annotator"),U.current=[])};o.useEffect(()=>{if(u!=="annotator"||!re||!j.current)return;const t=j.current,s=t.getContext("2d"),a=new Image;a.onload=()=>{t.width=a.width,t.height=a.height,s.drawImage(a,0,0),U.current=[s.getImageData(0,0,t.width,t.height)]},a.src=re},[u,re]);const Ge=t=>{const s=j.current.getBoundingClientRect(),a=j.current.width/s.width,n=j.current.height/s.height;return{x:(t.clientX-s.left)*a,y:(t.clientY-s.top)*n}},Mt=t=>{Q.current=!0;const s=Ge(t);f.current=s;const a=j.current.getContext("2d");if(ke.current=a.getImageData(0,0,j.current.width,j.current.height),_==="text"){const n=prompt("Enter label text:");if(n){a.font="bold 18px Inter, sans-serif",a.fillStyle=O,a.strokeStyle="rgba(0,0,0,0.6)",a.lineWidth=3,a.strokeText(n,s.x,s.y),a.fillText(n,s.x,s.y);const c=j.current;U.current.push(a.getImageData(0,0,c.width,c.height))}Q.current=!1}},Rt=t=>{if(!Q.current||_==="text")return;const s=j.current,a=s.getContext("2d"),n=Ge(t);if(ke.current&&a.putImageData(ke.current,0,0),a.strokeStyle=O,a.fillStyle=O,a.lineWidth=2,a.lineCap="round",_==="rect"&&(a.strokeStyle=O,a.lineWidth=2.5,a.strokeRect(f.current.x,f.current.y,n.x-f.current.x,n.y-f.current.y),a.fillStyle=Yt(O,.1),a.fillRect(f.current.x,f.current.y,n.x-f.current.x,n.y-f.current.y)),_==="arrow"){a.beginPath(),a.moveTo(f.current.x,f.current.y),a.lineTo(n.x,n.y),a.lineWidth=3,a.stroke();const c=Math.atan2(n.y-f.current.y,n.x-f.current.x),g=14;a.beginPath(),a.moveTo(n.x,n.y),a.lineTo(n.x-g*Math.cos(c-Math.PI/6),n.y-g*Math.sin(c-Math.PI/6)),a.lineTo(n.x-g*Math.cos(c+Math.PI/6),n.y-g*Math.sin(c+Math.PI/6)),a.closePath(),a.fillStyle=O,a.fill()}if(_==="blur"){const c=Math.abs(n.x-f.current.x),g=Math.abs(n.y-f.current.y),h=Math.min(n.x,f.current.x),x=Math.min(n.y,f.current.y);a.filter="blur(10px)",a.drawImage(s,h,x,c,g,h,x,c,g),a.filter="none",a.fillStyle="rgba(0,0,0,0.35)",a.fillRect(h,x,c,g)}},qe=()=>{if(!Q.current)return;Q.current=!1;const t=j.current,s=t.getContext("2d");U.current.push(s.getImageData(0,0,t.width,t.height))},At=()=>{if(U.current.length<=1)return;U.current.pop();const t=U.current[U.current.length-1];t&&j.current.getContext("2d").putImageData(t,0,0)},zt=()=>{if(je===null||!j.current)return;const t=j.current.toDataURL("image/jpeg",.92);L(s=>({...s,[je]:t})),chrome.storage.local.get("sessionScreenshots",s=>{const a=s.sessionScreenshots??{};a[je]=t,chrome.storage.local.set({sessionScreenshots:a})}),b("steps")},Ut=async()=>{if(r.length===0)return;Re(!0),z(null);const t=await chrome.runtime.sendMessage({type:"GENERATE_AI_CONTENT",payload:{steps:r}});if(Re(!1),t!=null&&t.error){z(t.error);return}t!=null&&t.title&&Ne(t.title),t!=null&&t.description&&Te(t.description),t!=null&&t.suggestedSeverity&&Ie(t.suggestedSeverity),t!=null&&t.stepsSummary&&de(t.stepsSummary)},Bt=async t=>{var a,n;t.preventDefault();let s=le;if(!s)try{const c=await chrome.storage.local.get(["currentSessionId","lastSessionId"]);s=c.currentSessionId||c.lastSessionId||crypto.randomUUID(),ce(s)}catch{s=crypto.randomUUID(),ce(s)}Me(!0),z(null);try{const g=(await Promise.all(Object.entries(d||{}).map(async([l,I])=>{const P=await Xt(I);return P?{stepIndex:Number(l),dataUrl:P}:null}))).filter(l=>l!==null),h=[];K&&h.push("jira"),V&&h.push("slack"),G&&h.push("azure-devops");const x={sessionId:s,title:w||"Untitled Bug",description:F,severity:N,reproductionConfidence:90,steps:(r||[]).map((l,I)=>({order:I+1,actionType:(l.actionType||"CLICK").toUpperCase(),elementLabel:(l.elementLabel||"Element").slice(0,499),timestamp:l.timestamp||new Date().toISOString(),valueMasked:l.valueMasked||void 0,cssSelector:(l.cssSelector||"").slice(0,1999)||void 0,pageUrl:(l.pageUrl||"").slice(0,1999)||void 0,pageTitle:(l.pageTitle||"").slice(0,999)||void 0})),attachments:g,networkLogs:W?(T||[]).filter(l=>l&&l.failed).slice(0,50).map(l=>({...l,url:(l.url||"").slice(0,19999)})):[],integrations:h,expectedResult:R.trim()||void 0,actualResult:A.trim()||void 0,consoleLogs:(M||[]).slice(-100),storageSnapshot:se||{},bugUrl:$.trim()||void 0,testData:B.trim()||void 0,mainImageIndex:y},i=await chrome.runtime.sendMessage({type:"API_REQUEST",payload:{url:"/v1/bugs",options:{method:"POST",body:JSON.stringify(x)}}});if(i.error){if((a=i.details)!=null&&a.errors&&Array.isArray(i.details.errors)){const l=i.details.errors.map(I=>{var P;return`${((P=I.path)==null?void 0:P.join("."))||"body"}: ${I.message}`}).join(", ");throw new Error(`Validation Error: ${l}`)}throw new Error(((n=i.details)==null?void 0:n.message)||i.error)}const p=[],k=y!==null&&d[y]?d[y]:Object.values(d)[0]||null,S={os:navigator.platform||"Unknown OS",browser:"Chrome Extension",resolution:`${window.screen.width}x${window.screen.height}`,userAgent:navigator.userAgent},v={title:w,description:F,severity:N,stepCount:r.length,url:$,expectedResult:R,actualResult:A,testSummary:D,steps:r,networkLogs:W?T.filter(l=>l.failed):[],consoleLogs:M,storageSnapshot:se,deviceFingerprint:S,screenshot:k,triageResult:E};if(K){const l=await chrome.runtime.sendMessage({type:"CREATE_JIRA_ISSUE",payload:{...v,issueType:he}});l!=null&&l.issueKey?p.push(`✅ Jira: ${l.issueKey}`):p.push(`⚠️ Jira: ${(l==null?void 0:l.detail)||"Failed — check backend .env"}`)}if(V){const l=await chrome.runtime.sendMessage({type:"SEND_SLACK_NOTIFICATION",payload:{...v,channel:J}});l!=null&&l.success?p.push(`✅ Slack: Notification sent to ${J}`):p.push(`⚠️ Slack: ${(l==null?void 0:l.detail)||"Failed — check SLACK_WEBHOOK_URL in .env"}`)}if(G){const l=await chrome.runtime.sendMessage({type:"CREATE_AZURE_WORK_ITEM",payload:{...v,workItemType:xe}});l!=null&&l.workItemId?p.push(`✅ Azure DevOps: #${l.workItemId}`):p.push(`⚠️ Azure: ${(l==null?void 0:l.detail)||"Failed — check AZURE_* vars in .env"}`)}p.length>0&&bt(p),dt(!0),await chrome.storage.local.remove(["sessionEvents","currentSessionId","stepCount","lastSessionId","sessionScreenshots","networkLogs"])}catch(c){z(c.message||"Submission failed")}finally{Me(!1)}},Ye=t=>{let s=F||"";return D&&(s+=`

Detailed Steps:
${D}`),A&&(s+=`

Actual Result:
${A}`),R&&(s+=`

Expected Result:
${R}`),$&&(s+=`

URL:
${$}`),B&&(s+=`

Test Data:
${B}`),s.slice(0,t)},Dt=async()=>{if(!w){q({type:"error",message:"Title is required to dispatch."});return}Pe(!0),q(null);try{const t=y!==null&&d[y]?d[y]:Object.values(d)[0]||null,s={os:navigator.platform||"Unknown OS",browser:"Chrome Extension",resolution:`${window.screen.width}x${window.screen.height}`,userAgent:navigator.userAgent},a={title:w,description:F,severity:N,issueType:he,url:$,expectedResult:R,actualResult:A,testSummary:D,steps:r,networkLogs:W?T.filter(c=>c.failed):[],consoleLogs:M,storageSnapshot:se,deviceFingerprint:s,screenshot:t,triageResult:E},n=await chrome.runtime.sendMessage({type:"CREATE_JIRA_ISSUE",payload:a});if(n!=null&&n.issueKey)q({type:"success",message:`Successfully created issue: ${n.issueKey}`});else{const c=(n==null?void 0:n.detail)||(n==null?void 0:n.error)||"Failed to dispatch to Jira. Check backend configuration.";q({type:"error",message:c})}}catch(t){q({type:"error",message:t.message||"Failed to dispatch to Jira."})}finally{Pe(!1)}},Ot=async()=>{if(!w){Y({type:"error",message:"Title is required to send notification."});return}_e(!0),Y(null);try{const t=Ye(1950),s={title:w,description:t,severity:N,stepCount:r.length},a=await chrome.runtime.sendMessage({type:"SEND_SLACK_NOTIFICATION",payload:{...s,channel:J}});a!=null&&a.success?Y({type:"success",message:`Notification successfully sent to ${J}!`}):Y({type:"error",message:(a==null?void 0:a.detail)||"Failed to send to Slack. Check backend webhook."})}catch(t){Y({type:"error",message:t.message||"Failed to send to Slack."})}finally{_e(!1)}},Pt=async()=>{if(!w){X({type:"error",message:"Title is required to dispatch."});return}He(!0),X(null);try{const t=Ye(31950),s={title:w,description:t,severity:N,stepCount:r.length},a=await chrome.runtime.sendMessage({type:"CREATE_AZURE_WORK_ITEM",payload:{...s,workItemType:xe}});a!=null&&a.workItemId?X({type:"success",message:`Successfully created work item: #${a.workItemId}`}):X({type:"error",message:(a==null?void 0:a.detail)||"Failed to dispatch to Azure. Check backend configuration."})}catch(t){X({type:"error",message:t.message||"Failed to dispatch to Azure."})}finally{He(!1)}},Xe=()=>{const t=D||r.map((s,a)=>{const n=s.elementLabel||"element",c=s.actionType.toUpperCase();if(c==="CLICK")return`${a+1}. Click on the "${n}".`;if(c==="INPUT"){const g=s.valueMasked&&s.valueMasked!=="[REDACTED]"?` "${s.valueMasked}"`:"";return`${a+1}. Enter${g} in the "${n}" field.`}return c==="NAVIGATE"?`${a+1}. Navigate to the next page.`:c==="SCROLL"?`${a+1}. Scroll the page.`:c==="HOVER"?`${a+1}. Hover over "${n}".`:`${a+1}. Perform ${s.actionType} on "${n}".`}).join(`
`);navigator.clipboard.writeText(t).then(()=>{Ae(!0),setTimeout(()=>Ae(!1),2e3)}).catch(()=>{})},Ze=()=>{const t=r.map((i,p)=>`
      <div class="step-card">
        <div class="step-header">
          <div class="step-num">${p+1}</div>
          <div class="step-body">
            <div class="step-action">
              <span class="action-icon">${rt[i.actionType.toUpperCase()]??"▶"}</span>
              <span class="action-type">${i.actionType}</span>
            </div>
            <div class="step-label">${i.actionType} on <strong>${i.elementLabel||"element"}</strong></div>
            <div class="step-meta">
              ${i.pageUrl?`<span class="step-url">${i.pageUrl}</span>`:""}
              <span class="step-time">${new Date(i.timestamp).toLocaleTimeString()}</span>
            </div>
          </div>
        </div>
        ${d[p]?`
        <div class="step-screenshot lightbox-trigger" data-src="${d[p]}" data-caption="Step ${p+1} screenshot">
          <img src="${d[p]}" alt="Step ${p+1}" style="cursor: zoom-in;" />
        </div>`:""}
      </div>
    `).join(""),s=Zt(D||r.map((i,p)=>{const k=i.elementLabel||"element",S=i.actionType.toUpperCase();if(S==="CLICK")return`${p+1}. Click on the "${k}".`;if(S==="INPUT"){const v=i.valueMasked&&i.valueMasked!=="[REDACTED]"?` "${i.valueMasked}"`:"";return`${p+1}. Enter${v} in the "${k}" field.`}return S==="NAVIGATE"?`${p+1}. Navigate to the next page.`:S==="SCROLL"?`${p+1}. Scroll the page.`:S==="HOVER"?`${p+1}. Hover over "${k}".`:`${p+1}. Perform ${i.actionType} on "${k}".`}).join(`
`)),a=T.filter(i=>i.failed).map(i=>`
      <details class="log-details failed">
        <summary class="log-summary">
          <div class="log-method">${i.method}</div>
          <div class="log-url">${i.url}</div>
          <div class="log-status">${i.status??"Failed"}</div>
        </summary>
        ${i.responseBody?`<div class="log-body"><strong>Response Body:</strong><pre>${i.responseBody}</pre></div>`:'<div class="log-body">No response body captured.</div>'}
      </details>
    `).join("")||'<p class="empty-state">No failed network logs captured.</p>',n=(M||[]).map(i=>`
      <div class="console-card ${i.type==="error"||i.type==="exception"?"failed":""}">
        <div class="console-type badge-${i.type}">${i.type.toUpperCase()}</div>
        <div class="console-text">${i.text}</div>
      </div>
    `).join("")||'<p class="empty-state">No console logs captured.</p>',c=navigator.userAgent;let g="Unknown Browser";c.includes("Firefox")?g="Firefox":c.includes("Edg")?g="Edge":c.includes("Chrome")?g="Chrome":c.includes("Safari")&&(g="Safari");let h="Unknown OS";c.includes("Win")?h="Windows":c.includes("Mac")?h="MacOS":c.includes("Linux")?h="Linux":c.includes("X11")&&(h="UNIX");const x=`${window.screen.width}x${window.screen.height}`;return`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bug Report: ${w||"Unnamed Bug"}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: #090d16;
      --panel: #111827;
      --card: #1f2937;
      --border: #374151;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --text: #f9fafb;
      --text2: #d1d5db;
      --text3: #9ca3af;
      --red: #ef4444;
      --red-bg: rgba(239, 68, 68, 0.12);
      --orange: #f97316;
      --green: #10b981;
      --blue: #3b82f6;
    }
    
    * { box-sizing: border-box; outline: none; }
    
    body {
      background: var(--bg);
      color: var(--text);
      font-family: 'Inter', sans-serif;
      margin: 0;
      padding: 0;
      min-height: 100vh;
      overflow-x: hidden;
      line-height: 1.5;
    }
    
    .page-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 32px 16px;
      display: flex;
      flex-direction: column;
      gap: 32px;
    }

    /* Main Section: Test Details */
    .details-section {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 32px;
      display: flex;
      flex-direction: column;
      gap: 24px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .brand-logo-svg {
      width: 18px;
      height: 18px;
      color: #818cf8;
      flex-shrink: 0;
    }

    .brand-text {
      font-size: 14px;
      font-weight: 700;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      background: linear-gradient(135deg, #818cf8 0%, #c084fc 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .header-info {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      flex-wrap: wrap;
      gap: 16px;
      border-bottom: 1px solid var(--border);
      padding-bottom: 20px;
    }

    .title-area {
      flex: 1;
      min-width: 300px;
    }

    h1 {
      margin: 4px 0 12px 0;
      font-size: 28px;
      font-weight: 700;
      color: #fff;
      line-height: 1.2;
    }

    .meta-pills {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }

    .severity-badge {
      display: inline-block;
      padding: 4px 10px;
      border-radius: 6px;
      font-weight: 700;
      font-size: 11px;
      background: var(--red-bg);
      color: var(--red);
      border: 1px solid rgba(239, 68, 68, 0.2);
      text-transform: uppercase;
    }

    .url-badge {
      display: inline-flex;
      align-items: center;
      padding: 4px 10px;
      border-radius: 6px;
      font-weight: 500;
      font-size: 11px;
      background: rgba(99, 102, 241, 0.12);
      color: var(--primary);
      border: 1px solid rgba(99, 102, 241, 0.2);
      text-decoration: none;
      word-break: break-all;
    }

    .url-badge:hover {
      background: var(--primary);
      color: #fff;
    }

    .details-grid {
      display: grid;
      grid-template-columns: 2fr 1fr;
      gap: 24px;
    }

    @media (max-width: 900px) {
      .details-grid {
        grid-template-columns: 1fr;
      }
    }

    .grid-left {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }

    .grid-right {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }

    .section-card {
      background: rgba(255, 255, 255, 0.02);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 20px;
    }

    .card-label {
      font-size: 11px;
      text-transform: uppercase;
      color: var(--text3);
      font-weight: 700;
      letter-spacing: 0.05em;
      display: block;
      margin-bottom: 8px;
    }

    .card-content {
      font-size: 14px;
      color: var(--text2);
    }

    .results-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
    }

    @media (max-width: 600px) {
      .results-row {
        grid-template-columns: 1fr;
      }
    }

    /* Device details */
    .device-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
      gap: 12px;
    }

    .device-item {
      background: rgba(255, 255, 255, 0.01);
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .device-value {
      font-size: 13px;
      color: var(--text);
      font-weight: 600;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    /* Main screenshot card */
    .main-screenshot-card {
      position: relative;
      cursor: zoom-in;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    .main-screenshot-card img {
      width: 100%;
      height: auto;
      border-radius: 8px;
      border: 1px solid var(--border);
      transition: transform 0.2s ease;
      display: block;
    }

    .main-screenshot-card:hover img {
      transform: scale(1.02);
    }

    /* Test Summary formatting */
    .steps-plain-block {
      font-family: monospace;
      font-size: 13px;
      color: var(--text2);
      white-space: pre-wrap;
      line-height: 1.5;
      margin: 0;
      position: relative;
    }

    .steps-copy-btn {
      position: absolute;
      top: 12px;
      right: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 32px;
      height: 32px;
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid var(--border);
      border-radius: 6px;
      color: var(--text2);
      cursor: pointer;
      z-index: 10;
      transition: all 0.2s ease;
    }
    
    .steps-copy-btn:hover {
      background: rgba(255, 255, 255, 0.15);
      color: var(--text);
    }

    /* Tabular module */
    .tabs-section {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 16px;
      overflow: hidden;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
    }

    .tab-btn-bar {
      display: flex;
      border-bottom: 1px solid var(--border);
      background: rgba(255, 255, 255, 0.01);
      overflow-x: auto;
    }

    .tab-btn {
      padding: 18px 24px;
      font-size: 13px;
      font-weight: 600;
      color: var(--text3);
      background: transparent;
      border: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 8px;
      border-bottom: 2px solid transparent;
      transition: all 0.2s ease;
      white-space: nowrap;
    }

    .tab-btn:hover {
      color: var(--text2);
      background: rgba(255, 255, 255, 0.02);
    }

    .tab-btn.active {
      color: var(--primary);
      border-bottom-color: var(--primary);
      background: rgba(99, 102, 241, 0.03);
    }

    .tab-icon {
      width: 16px;
      height: 16px;
    }

    .tab-content {
      padding: 32px;
    }

    .tab-panel {
      display: none;
      animation: fadeIn 0.2s ease-in-out forwards;
    }

    .tab-panel.active {
      display: block;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(4px); }
      to { opacity: 1; transform: translateY(0); }
    }

    /* Detailed Steps Timeline */
    .step-card {
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 20px;
      margin-bottom: 16px;
      display: flex;
      flex-direction: column;
      gap: 16px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    
    .step-header {
      display: flex;
      gap: 16px;
    }
    
    .step-num {
      width: 28px;
      height: 28px;
      background: var(--primary);
      color: white;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 700;
      font-size: 13px;
      flex-shrink: 0;
    }
    
    .step-body { flex: 1; min-width: 0; }
    
    .step-action {
      display: flex;
      align-items: center;
      gap: 6px;
      margin-bottom: 4px;
    }
    
    .action-type {
      font-weight: 700;
      text-transform: uppercase;
      font-size: 11px;
      color: var(--primary);
      letter-spacing: 0.05em;
    }
    
    .step-label { font-weight: 500; font-size: 14px; word-break: break-word; color: #fff; }
    
    .step-meta {
      display: flex;
      flex-wrap: wrap;
      gap: 12px;
      font-size: 11px;
      color: var(--text3);
      margin-top: 8px;
    }
    
    .step-url {
      background: var(--bg);
      padding: 2px 6px;
      border-radius: 4px;
      border: 1px solid var(--border);
      max-width: 300px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .step-screenshot {
      max-width: 100%;
      border-radius: 8px;
      overflow: hidden;
      border: 1px solid var(--border);
    }
    
    .step-screenshot img {
      width: 100%;
      max-height: 450px;
      object-fit: contain;
      display: block;
    }

    /* Expandable Logs (Network & Console) */
    .log-details {
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 8px;
      margin-bottom: 12px;
      overflow: hidden;
    }
    
    .log-details.failed {
      border-left: 4px solid var(--red);
    }
    
    .log-summary {
      display: flex;
      padding: 16px;
      cursor: pointer;
      align-items: center;
      font-family: monospace;
      font-size: 13px;
      user-select: none;
    }
    
    .log-summary:hover { background: rgba(255, 255, 255, 0.02); }
    
    .log-method {
      font-weight: 700;
      color: var(--red);
      width: 60px;
    }
    
    .log-url {
      color: var(--text2);
      flex: 1;
      margin: 0 16px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    .log-status { color: var(--red); font-weight: 600; }
    
    .log-body {
      padding: 16px;
      border-top: 1px solid var(--border);
      background: var(--bg);
      font-family: monospace;
      font-size: 12px;
      color: var(--text2);
      overflow-x: auto;
    }
    
    .log-body pre { margin: 8px 0 0 0; white-space: pre-wrap; }
    
    /* Console Logs */
    .console-card {
      display: flex;
      gap: 16px;
      padding: 12px 16px;
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 8px;
      margin-bottom: 8px;
      font-family: monospace;
      font-size: 13px;
    }
    
    .console-card.failed { border-left: 4px solid var(--red); }
    
    .console-type {
      padding: 2px 8px;
      border-radius: 4px;
      font-weight: 700;
      font-size: 10px;
      text-transform: uppercase;
      align-self: flex-start;
    }
    
    .badge-error, .badge-exception { background: var(--red-bg); color: var(--red); }
    .badge-warn { background: rgba(249, 115, 22, 0.12); color: var(--orange); }
    .badge-info, .badge-log { background: rgba(59, 130, 246, 0.12); color: var(--blue); }
    
    .console-text {
      color: var(--text2);
      white-space: pre-wrap;
      word-break: break-all;
    }
    
    /* Code/JSON Block */
    .code-block {
      background: #0d1117;
      padding: 20px;
      border-radius: 8px;
      border: 1px solid var(--border);
      overflow-x: auto;
      font-family: monospace;
      font-size: 13px;
      color: #c9d1d9;
      line-height: 1.5;
    }
    
    .json-key { color: #79c0ff; }
    .json-string { color: #a5d6ff; }
    .json-number { color: #f2cc60; }
    .json-boolean { color: #ff7b72; }

    /* Lightbox Modal */
    .lightbox {
      display: none;
      position: fixed;
      z-index: 1000;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(9, 13, 22, 0.95);
      backdrop-filter: blur(8px);
      align-items: center;
      justify-content: center;
      opacity: 0;
      transition: opacity 0.25s ease;
    }

    .lightbox.open {
      display: flex;
      opacity: 1;
    }

    .lightbox-content {
      max-width: 90%;
      max-height: 85%;
      border-radius: 8px;
      border: 1px solid var(--border);
      box-shadow: 0 10px 40px rgba(0,0,0,0.5);
      object-fit: contain;
    }

    .lightbox-caption {
      position: absolute;
      bottom: 24px;
      color: var(--text2);
      font-weight: 500;
      background: rgba(0, 0, 0, 0.6);
      padding: 8px 16px;
      border-radius: 20px;
      font-size: 13px;
    }

    .lightbox-close {
      position: absolute;
      top: 24px;
      right: 24px;
      color: var(--text3);
      font-size: 32px;
      font-weight: bold;
      cursor: pointer;
      transition: color 0.15s;
    }

    .lightbox-close:hover {
      color: #fff;
    }
    
    /* Print Styles */
    @media print {
      body {
        background: white !important;
        color: black !important;
      }
      .page-container {
        padding: 0 !important;
        gap: 20px !important;
      }
      .details-section, .tabs-section, .section-card, .device-item {
        border-color: #ddd !important;
        background: white !important;
        box-shadow: none !important;
      }
      * {
        color: black !important;
        text-shadow: none !important;
        box-shadow: none !important;
      }
      .tab-btn-bar { display: none !important; }
      .tab-content { padding: 0 !important; }
      .tab-panel {
        display: block !important;
        opacity: 1 !important;
        visibility: visible !important;
      }
      .tab-panel::before {
        content: attr(data-title);
        display: block;
        font-size: 18px;
        font-weight: 700;
        margin-top: 30px;
        margin-bottom: 12px;
        border-bottom: 2px solid #555 !important;
        padding-bottom: 4px;
      }
      .step-card, .log-details, .console-card, .code-block {
        page-break-inside: avoid;
        border: 1px solid #ccc !important;
        background: white !important;
      }
      details { display: block !important; }
      details summary ~ * { display: block !important; }
      .lightbox { display: none !important; }
    }
  </style>
</head>
<body>
  
  <div class="page-container">
    
    <!-- Test Details Main Section -->
    <section class="details-section">
      <div class="brand">
        <svg class="brand-logo-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <rect x="6" y="8" width="12" height="11" rx="4" />
          <path d="M12 8V4" />
          <path d="M9 12h6" />
          <path d="M9 4.5a3 3 0 0 1 6 0" />
          <path d="M4 10h2" />
          <path d="M18 10h2" />
          <path d="M3 14h3" />
          <path d="M18 14h3" />
          <path d="M4 18h2" />
          <path d="M18 18h2" />
        </svg>
        <span class="brand-text">BugBuddy Report</span>
      </div>

      <div class="header-info">
        <div class="title-area">
          <span class="severity-badge" style="background-color: ${N==="P0"?"rgba(239, 68, 68, 0.15)":N==="P1"?"rgba(249, 115, 22, 0.15)":"rgba(59, 130, 246, 0.15)"}; color: ${N==="P0"?"var(--red)":N==="P1"?"var(--orange)":"var(--blue)"}; border-color: ${N==="P0"?"var(--red)":N==="P1"?"var(--orange)":"var(--blue)"}">${N}</span>
          <h1>${w||"Unnamed Bug"}</h1>
          <div class="meta-pills">
            ${$?`<a href="${$}" target="_blank" class="url-badge">
              <svg style="width:12px;height:12px;margin-right:4px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
              ${$}
            </a>`:""}
          </div>
        </div>
      </div>

      <div class="details-grid">
        <div class="grid-left">
          
          <div class="section-card">
            <span class="card-label">Description</span>
            <div class="card-content">${F||"No description provided."}</div>
          </div>

          <div class="results-row">
            ${R?`
            <div class="section-card">
              <span class="card-label">Expected Result</span>
              <div class="card-content">${R}</div>
            </div>
            `:""}

            ${A?`
            <div class="section-card">
              <span class="card-label">Actual Result</span>
              <div class="card-content">${A}</div>
            </div>
            `:""}
          </div>

          ${B?`
          <div class="section-card">
            <span class="card-label">Test Data</span>
            <div class="card-content" style="font-family: monospace; white-space: pre-wrap; font-size: 13px; background: rgba(0,0,0,0.2); padding: 8px 12px; border-radius: 6px; border: 1px solid var(--border);">${B}</div>
          </div>
          `:""}

          <div class="section-card">
            <span class="card-label">Device Details</span>
            <div class="device-grid">
              <div class="device-item">
                <span class="card-label" style="font-size:9px; margin-bottom: 2px;">OS</span>
                <span class="device-value" title="${h}">${h}</span>
              </div>
              <div class="device-item">
                <span class="card-label" style="font-size:9px; margin-bottom: 2px;">Browser</span>
                <span class="device-value" title="${g}">${g}</span>
              </div>
              <div class="device-item">
                <span class="card-label" style="font-size:9px; margin-bottom: 2px;">Resolution</span>
                <span class="device-value" title="${x}">${x}</span>
              </div>
              <div class="device-item" style="grid-column: span 2;">
                <span class="card-label" style="font-size:9px; margin-bottom: 2px;">User Agent</span>
                <span class="device-value" style="font-size:11px;" title="${c}">${c}</span>
              </div>
            </div>
          </div>

        </div>
        
        <div class="grid-right">
          
          <div class="section-card" style="position: relative;">
            <span class="card-label">Test Summary</span>
            <button id="copy-steps-btn" class="steps-copy-btn" title="Copy summary steps">
              <svg style="width: 14px; height: 14px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3"></path></svg>
            </button>
            <pre id="steps-summary-text" class="steps-plain-block">${s||"No steps captured."}</pre>
          </div>

          ${y!==null&&d[y]?`
          <div class="section-card">
            <span class="card-label">Main Screenshot</span>
            <div class="main-screenshot-card lightbox-trigger" data-src="${d[y]}" data-caption="Main Screenshot">
              <img src="${d[y]}" alt="Main Screenshot" />
            </div>
          </div>
          `:""}

        </div>
      </div>
    </section>

    <!-- Tabular Module Section -->
    <section class="tabs-section">
      <div class="tab-btn-bar">
        <button class="tab-btn active" data-tab="timeline">
          <svg class="tab-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3.01" y2="6"></line><line x1="3" y1="12" x2="3.01" y2="12"></line><line x1="3" y1="18" x2="3.01" y2="18"></line></svg>
          Detailed Steps
        </button>
        <button class="tab-btn" data-tab="network">
          <svg class="tab-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.55a11 11 0 0 1 14.08 0"></path><path d="M1.42 9a16 16 0 0 1 21.16 0"></path><path d="M8.53 16.11a6 6 0 0 1 6.95 0"></path><line x1="12" y1="20" x2="12.01" y2="20"></line></svg>
          Failed Network Logs
        </button>
        <button class="tab-btn" data-tab="console">
          <svg class="tab-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 17 10 11 4 5"></polyline><line x1="12" y1="19" x2="20" y2="19"></line></svg>
          Console Logs
        </button>
        <button class="tab-btn" data-tab="storage">
          <svg class="tab-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="9" ry="3"></ellipse><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path><path d="M3 12c0 1.66 4 3 9 3s9-1.34 9-3"></path></svg>
          App Storage
        </button>
      </div>

      <div class="tab-content">
        
        <!-- Tab 1: Detailed Steps Timeline -->
        <div id="timeline" class="tab-panel active" data-title="Detailed Steps">
          ${t||'<p class="empty-state">No steps captured during session.</p>'}
        </div>

        <!-- Tab 2: Failed Network Logs -->
        <div id="network" class="tab-panel" data-title="Failed Network Logs">
          ${a}
        </div>

        <!-- Tab 3: Console Logs -->
        <div id="console" class="tab-panel" data-title="Console Logs">
          ${n}
        </div>

        <!-- Tab 4: App Storage -->
        <div id="storage" class="tab-panel" data-title="Application Storage">
          <pre class="code-block">${JSON.stringify(se,null,2).replace(/"([^"]+)":/g,'<span class="json-key">"$1"</span>:').replace(/: "([^"]+)"/g,': <span class="json-string">"$1"</span>').replace(/: ([0-9]+)/g,': <span class="json-number">$1</span>').replace(/: (true|false)/g,': <span class="json-boolean">$1</span>')}</pre>
        </div>

      </div>
    </section>

  </div>

  <!-- Lightbox Modal -->
  <div id="lightbox" class="lightbox">
    <span class="lightbox-close">&times;</span>
    <img class="lightbox-content" id="lightbox-img">
    <div id="lightbox-caption" class="lightbox-caption"></div>
  </div>
  
  <script>
    // Tab Switching Logic
    function switchTab(tabId) {
      var buttons = document.querySelectorAll('.tab-btn');
      for (var i = 0; i < buttons.length; i++) {
        buttons[i].classList.remove('active');
      }
      var panels = document.querySelectorAll('.tab-panel');
      for (var i = 0; i < panels.length; i++) {
        panels[i].classList.remove('active');
      }
      var targetBtn = document.querySelector('[data-tab="' + tabId + '"]');
      if (targetBtn) targetBtn.classList.add('active');
      
      var targetPanel = document.getElementById(tabId);
      if (targetPanel) targetPanel.classList.add('active');
    }

    // Lightbox Logic
    function openLightbox(src, caption) {
      var lightbox = document.getElementById('lightbox');
      var img = document.getElementById('lightbox-img');
      var cap = document.getElementById('lightbox-caption');
      if (lightbox && img && cap) {
        img.src = src;
        cap.innerText = caption || 'Screenshot Preview';
        lightbox.classList.add('open');
      }
    }

    // Close Lightbox Logic
    function closeLightbox() {
      var lightbox = document.getElementById('lightbox');
      if (lightbox) {
        lightbox.classList.remove('open');
      }
    }

    // Copy Steps Logic
    function copyStepsToClipboard() {
      var textEl = document.getElementById('steps-summary-text');
      if (!textEl) return;
      var text = textEl.innerText;
      
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(showCopySuccess).catch(function(err) {
          console.error('Failed to copy steps:', err);
          fallbackCopyText(text);
        });
      } else {
        fallbackCopyText(text);
      }
    }

    function showCopySuccess() {
      var btn = document.getElementById('copy-steps-btn');
      if (!btn) return;
      var origIcon = btn.innerHTML;
      btn.innerHTML = '<svg style="width: 16px; height: 16px; color: #10b981;" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"></path></svg>';
      btn.style.borderColor = '#10b981';
      btn.style.background = 'rgba(16, 185, 129, 0.1)';
      setTimeout(function() {
        btn.innerHTML = origIcon;
        btn.style.borderColor = '';
        btn.style.background = '';
      }, 2000);
    }

    function fallbackCopyText(text) {
      var textArea = document.createElement("textarea");
      textArea.value = text;
      textArea.style.position = "fixed";  // avoid scrolling to bottom
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      try {
        var successful = document.execCommand('copy');
        if (successful) {
          showCopySuccess();
        } else {
          console.error('Fallback copy was unsuccessful');
        }
      } catch (err) {
        console.error('Fallback copy failed:', err);
      }
      document.body.removeChild(textArea);
    }

    // Setup and initialization
    function init() {
      // Tab switcher event listeners
      document.querySelectorAll('.tab-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
          var tabId = btn.getAttribute('data-tab');
          switchTab(tabId);
        });
      });

      // Lightbox triggers
      document.addEventListener('click', function(e) {
        var trigger = e.target.closest('.lightbox-trigger');
        if (trigger) {
          var src = trigger.getAttribute('data-src');
          var caption = trigger.getAttribute('data-caption');
          openLightbox(src, caption);
        }
      });

      // Lightbox close trigger (background click)
      var lightbox = document.getElementById('lightbox');
      if (lightbox) {
        lightbox.addEventListener('click', function() {
          closeLightbox();
        });
      }

      // Close button trigger
      var lightboxClose = document.querySelector('.lightbox-close');
      if (lightboxClose) {
        lightboxClose.addEventListener('click', function(e) {
          e.stopPropagation();
          closeLightbox();
        });
      }

      // Prevent click inside lightbox image from closing it
      var lightboxImg = document.getElementById('lightbox-img');
      if (lightboxImg) {
        lightboxImg.addEventListener('click', function(e) {
          e.stopPropagation();
        });
      }

      // Copy steps button
      var copyBtn = document.getElementById('copy-steps-btn');
      if (copyBtn) {
        copyBtn.addEventListener('click', function() {
          copyStepsToClipboard();
        });
      }
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init);
    } else {
      init();
    }

    // Keydown handler (Escape key)
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') {
        closeLightbox();
      }
    });
  <\/script>
</body>
</html>
    `},ie=T.filter(t=>t.failed).length,Ce=T.filter(t=>oe?t.failed:!0),Ft=t=>t?t>=500?"error":t>=400?"warn":t>=300?"info":"success":"unknown",Qe=t=>t.elementLabel?t.elementLabel:t.text?`"${t.text.substring(0,20)}..."`:t.tagName?t.tagName.toLowerCase():t.actionType,_t=()=>{const t=Ze(),s=new Blob([t],{type:"text/html"}),a=URL.createObjectURL(s);chrome.downloads.download({url:a,filename:`bug-report-${Date.now()}.html`})},Wt=()=>{const t=Ze(),s=window.open("","_blank");s&&(s.document.write(t),s.document.close(),s.focus(),setTimeout(()=>{s.print(),s.close()},500))};return e.jsxs("div",{className:"panel",children:[e.jsxs("div",{className:"panel-header",children:[e.jsxs("div",{className:"header-top",children:[e.jsxs("div",{className:"brand",style:{display:"flex",alignItems:"center",gap:"8px"},children:[e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round",style:{width:"18px",height:"18px",color:"#818cf8",flexShrink:0},children:[e.jsx("rect",{x:"6",y:"8",width:"12",height:"11",rx:"4"}),e.jsx("path",{d:"M12 8V4"}),e.jsx("path",{d:"M9 12h6"}),e.jsx("path",{d:"M9 4.5a3 3 0 0 1 6 0"}),e.jsx("path",{d:"M4 10h2"}),e.jsx("path",{d:"M18 10h2"}),e.jsx("path",{d:"M3 14h3"}),e.jsx("path",{d:"M18 14h3"}),e.jsx("path",{d:"M4 18h2"}),e.jsx("path",{d:"M18 18h2"})]}),e.jsx("span",{className:"brand-name",children:"BugBuddy"})]}),e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"8px"},children:[le&&e.jsxs("div",{className:"session-chip",children:["#",le.slice(-6).toUpperCase()]}),e.jsx("button",{onClick:()=>ue(!Ue),style:{background:"none",border:"none",color:"var(--text3)",cursor:"pointer",display:"flex",padding:0},title:"Settings",id:"sidepanel-settings-btn",children:e.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16",fill:"none",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round",style:{transition:"color 0.2s"},onMouseEnter:t=>t.currentTarget.style.color="var(--text2)",onMouseLeave:t=>t.currentTarget.style.color="var(--text3)",children:[e.jsx("circle",{cx:"12",cy:"12",r:"3"}),e.jsx("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"})]})})]})]}),e.jsx("div",{className:"tabs",children:["steps","replay","annotator","network","report"].map(t=>e.jsxs("button",{className:`tab${u===t?" active":""}`,onClick:()=>b(t),children:[t==="steps"&&e.jsxs(e.Fragment,{children:[e.jsx("span",{children:"Steps"}),r.length>0&&e.jsx("span",{className:"tab-badge",children:r.length})]}),t==="replay"&&e.jsxs(e.Fragment,{children:[e.jsx("span",{children:"▶ Replay"}),r.length>0&&e.jsx("span",{className:"tab-badge",children:r.length})]}),t==="annotator"&&e.jsxs(e.Fragment,{children:[e.jsx("span",{children:"Annotate"}),Object.keys(d).length>0&&e.jsx("span",{className:"tab-badge",children:Object.keys(d).length})]}),t==="network"&&e.jsxs(e.Fragment,{children:[e.jsx("span",{children:"Network"}),ie>0&&e.jsx("span",{className:"tab-badge red",children:ie})]}),t==="report"&&e.jsx("span",{children:"Report"})]},t))})]}),Ue&&e.jsxs("div",{style:{background:"var(--bg2)",borderBottom:"1px solid var(--border)",padding:"12px 16px",display:"flex",flexDirection:"column",gap:"10px"},children:[e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center"},children:[e.jsx("span",{style:{fontWeight:600,fontSize:"11px",textTransform:"uppercase",letterSpacing:"0.05em",color:"var(--text2)"},children:"Settings"}),e.jsx("button",{onClick:()=>ue(!1),style:{background:"none",border:"none",color:"var(--text3)",cursor:"pointer",fontSize:"16px",display:"flex",padding:0},children:"×"})]}),e.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"6px"},children:[e.jsx("label",{style:{fontSize:"10px",color:"var(--text3)",fontWeight:500},children:"BugBuddy API Server URL"}),e.jsxs("div",{style:{display:"flex",gap:"8px"},children:[e.jsx("input",{type:"text",value:Be,onChange:t=>De(t.target.value),placeholder:"e.g. http://localhost:8080",style:{flex:1,background:"var(--bg3)",border:"1px solid var(--border)",borderRadius:"6px",padding:"6px 10px",color:"var(--text)",fontSize:"12px",fontFamily:"monospace",outline:"none"}}),e.jsx("button",{onClick:$t,style:{background:"linear-gradient(135deg, var(--accent) 0%, #818cf8 100%)",color:"#fff",border:"none",borderRadius:"6px",padding:"6px 12px",fontWeight:600,fontSize:"11px",cursor:"pointer"},children:"Save"})]})]})]}),e.jsxs("div",{className:"tab-content",children:[u==="steps"&&e.jsx("div",{className:"steps-list",children:r.length===0?e.jsxs("div",{className:"empty-state",children:[e.jsx("span",{className:"empty-icon",children:"📋"}),"No steps recorded yet.",e.jsx("br",{}),e.jsxs("small",{children:["Start recording and interact with the page.",e.jsx("br",{}),"Press ",e.jsx("kbd",{style:{background:"var(--bg3)",padding:"1px 4px",borderRadius:3,border:"1px solid var(--border)"},children:"Ctrl+I"})," to capture a screenshot."]})]}):e.jsxs(e.Fragment,{children:[e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12,padding:"0 4px"},children:[e.jsxs("span",{style:{fontSize:12,color:"var(--text3)"},children:[r.length," steps recorded"]}),e.jsx("button",{onClick:Xe,style:{background:H?"#10b981":"var(--bg3)",color:H?"#fff":"var(--text)",border:"1px solid var(--border)",borderRadius:6,padding:"4px 10px",fontSize:12,fontWeight:600,cursor:"pointer",display:"flex",alignItems:"center",gap:4,transition:"all 0.2s"},children:H?e.jsxs(e.Fragment,{children:[e.jsx("svg",{style:{width:12,height:12},fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",xmlns:"http://www.w3.org/2000/svg",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2",d:"M5 13l4 4L19 7"})}),e.jsx("span",{children:"Copied"})]}):e.jsxs(e.Fragment,{children:[e.jsx("svg",{style:{width:12,height:12},fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",xmlns:"http://www.w3.org/2000/svg",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2",d:"M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3"})}),e.jsx("span",{children:"Copy Steps Summary"})]})})]}),r.map((t,s)=>e.jsxs("div",{className:"step-card",children:[e.jsx("div",{className:"step-num",children:s+1}),e.jsxs("div",{className:"step-body",children:[e.jsxs("div",{className:"step-action",children:[e.jsx("span",{className:"action-icon",children:rt[(t.actionType||"CLICK").toUpperCase()]??"▶"}),e.jsx("span",{className:"action-type",children:t.actionType||"CLICK"})]}),e.jsx("div",{className:"step-label",children:Qe(t)}),e.jsxs("div",{className:"step-meta",children:[(t.pageUrl||t.toUrl)&&e.jsx("span",{className:"step-url",title:t.toUrl||t.pageUrl,children:(t.toUrl||t.pageUrl||"").replace(/^https?:\/\//,"").slice(0,40)}),e.jsx("span",{className:"step-time",children:t.timestamp?new Date(t.timestamp).toLocaleTimeString():""})]})]}),e.jsxs("div",{className:"step-thumb",onClick:()=>d[s]?Lt(s):void 0,title:d[s]?"Click to annotate":"No screenshot yet",style:d[s]?{}:{border:"1px dashed var(--border)",background:"transparent"},children:[d[s]?e.jsx("img",{src:d[s],alt:`step ${s+1}`}):e.jsx("div",{className:"no-shot",style:{fontSize:10,color:"var(--text3)"},children:"No image"}),d[s]&&e.jsx("div",{className:"thumb-badge",children:"Edit"})]}),e.jsxs("div",{className:"step-actions",children:[e.jsx("button",{className:`btn-icon main-image-toggle${y===s?" active":""}`,title:y===s?"Remove as Main Screenshot":"Set as Main Screenshot",onClick:()=>pe(y===s?null:s),disabled:!d[s],style:d[s]?{}:{cursor:"not-allowed",opacity:.3},children:y===s?"★":"☆"}),e.jsx("button",{className:"btn-icon capture",title:"Capture screenshot now",onClick:()=>Et(s),children:"📷"}),e.jsx("button",{className:"btn-icon delete",title:"Delete step",onClick:()=>Je(s),children:"✕"})]})]},s))]})}),u==="replay"&&e.jsx("div",{className:"replay-container",style:{display:"flex",flexDirection:"column",gap:16},children:r.length===0?e.jsxs("div",{className:"empty-state",children:[e.jsx("span",{className:"empty-icon",children:"▶"}),"No session steps recorded to replay.",e.jsx("br",{}),e.jsx("small",{children:"Record a test session first to playback visual step timelines."})]}):e.jsxs(e.Fragment,{children:[e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",background:"var(--bg2)",padding:"10px 14px",borderRadius:8,border:"1px solid var(--border)",flexWrap:"wrap",gap:8},children:[e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:8},children:[e.jsx("button",{type:"button",onClick:()=>Ve(!Z),style:{background:Z?"#f59e0b":"linear-gradient(135deg, var(--accent) 0%, #818cf8 100%)",color:"#fff",border:"none",borderRadius:6,padding:"6px 14px",fontWeight:700,fontSize:12,cursor:"pointer",display:"flex",alignItems:"center",gap:6},children:Z?"⏸ Pause":"▶ Play Replay"}),e.jsx("button",{type:"button",onClick:()=>ae(t=>Math.max(0,t-1)),disabled:m===0,style:{background:"var(--bg3)",border:"1px solid var(--border)",color:"var(--text)",borderRadius:6,padding:"6px 10px",fontSize:12,cursor:m===0?"not-allowed":"pointer",opacity:m===0?.4:1},children:"⏮ Prev"}),e.jsx("button",{type:"button",onClick:()=>ae(t=>Math.min(r.length-1,t+1)),disabled:m===r.length-1,style:{background:"var(--bg3)",border:"1px solid var(--border)",color:"var(--text)",borderRadius:6,padding:"6px 10px",fontSize:12,cursor:m===r.length-1?"not-allowed":"pointer",opacity:m===r.length-1?.4:1},children:"Next ⏭"})]}),e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:10},children:[e.jsxs("div",{style:{display:"flex",gap:4,alignItems:"center"},children:[e.jsx("span",{style:{fontSize:11,color:"var(--text3)",fontWeight:600},children:"Speed:"}),[.5,1,2,4].map(t=>e.jsxs("button",{type:"button",onClick:()=>yt(t),style:{background:ne===t?"var(--accent)":"var(--bg3)",color:ne===t?"#fff":"var(--text2)",border:"1px solid var(--border)",borderRadius:4,padding:"2px 6px",fontSize:11,fontWeight:600,cursor:"pointer"},children:[t,"x"]},t))]}),e.jsx("button",{type:"button",onClick:Ct,disabled:ve,style:{background:"rgba(16, 185, 129, 0.15)",color:"#10b981",border:"1px solid rgba(16, 185, 129, 0.4)",borderRadius:6,padding:"6px 10px",fontWeight:600,fontSize:11,cursor:ve?"wait":"pointer",display:"flex",alignItems:"center",gap:4},children:ve?"⏳ Exporting...":"🎥 Export WebM Video"})]})]}),e.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:4},children:[e.jsx("input",{type:"range",min:0,max:r.length-1,value:m,onChange:t=>ae(Number(t.target.value)),style:{width:"100%",accentColor:"var(--accent)",cursor:"pointer"}}),e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",fontSize:11,color:"var(--text3)"},children:[e.jsxs("span",{children:["Step ",m+1," of ",r.length]}),e.jsx("span",{children:(et=r[m])!=null&&et.timestamp?new Date(r[m].timestamp).toLocaleTimeString():""})]})]}),r[m]&&e.jsxs("div",{style:{background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:10,padding:16,display:"flex",flexDirection:"column",gap:12},children:[e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:8},children:[e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:8},children:[e.jsxs("span",{style:{background:"var(--accent)",color:"#fff",padding:"3px 8px",borderRadius:4,fontWeight:700,fontSize:12},children:["Step #",m+1]}),e.jsxs("span",{style:{fontWeight:600,fontSize:14,color:"var(--text)"},children:[(((tt=r[m])==null?void 0:tt.actionType)||"CLICK").toUpperCase(),' on "',Qe(r[m]),'"']})]}),((st=r[m])==null?void 0:st.pageUrl)&&e.jsx("span",{style:{fontSize:11,color:"var(--text3)",background:"var(--bg3)",padding:"2px 8px",borderRadius:4,wordBreak:"break-all"},children:r[m].pageUrl})]}),e.jsx("div",{style:{position:"relative",width:"100%",background:"#090d16",borderRadius:8,overflow:"hidden",border:"1px solid var(--border)",display:"flex",justifyContent:"center"},children:d[m]?e.jsx("img",{src:d[m],alt:`Step ${m+1}`,style:{width:"100%",maxHeight:360,objectFit:"contain",display:"block"}}):e.jsx("div",{style:{padding:40,color:"var(--text3)",fontSize:12},children:"No screenshot captured for this step"})})]})]})}),u==="annotator"&&e.jsx("div",{className:"annotator-wrap",children:re?e.jsxs("div",{className:"annotator-container",children:[e.jsxs("div",{className:"annotator-toolbar",children:[["arrow","rect","text","blur"].map(t=>e.jsxs("button",{className:`tool-btn${_===t?" active":""}`,onClick:()=>jt(t),children:[t==="arrow"&&"↗ Arrow",t==="rect"&&"▭ Highlight",t==="text"&&"T Label",t==="blur"&&"◻ Redact"]},t)),e.jsx("div",{className:"tool-sep"}),nt.map(t=>e.jsx("div",{className:`color-btn${O===t?" active":""}`,style:{background:t},onClick:()=>kt(t),title:t},t)),e.jsx("div",{className:"tool-sep"}),e.jsx("button",{className:"tool-btn",onClick:At,children:"↩ Undo"})]}),e.jsx("div",{className:"annotator-canvas-wrap",children:e.jsx("canvas",{ref:j,id:"annotator-canvas",onMouseDown:Mt,onMouseMove:Rt,onMouseUp:qe,onMouseLeave:qe})}),e.jsxs("div",{className:"annotator-footer",children:[e.jsx("button",{className:"tool-btn",onClick:()=>b("steps"),children:"← Back"}),e.jsx("button",{className:"tool-btn active",onClick:zt,children:"💾 Save Annotation"})]})]}):e.jsxs("div",{className:"annotator-placeholder",children:[e.jsx("div",{style:{fontSize:32,marginBottom:8},children:"🖼️"}),"Click a step's screenshot thumbnail to open it here for annotation."]})}),u==="network"&&e.jsxs("div",{children:[e.jsxs("div",{className:"net-toolbar",children:[e.jsx("input",{className:"net-search",placeholder:"Filter by URL…",value:Nt,onChange:t=>Tt(t.target.value)}),e.jsx("button",{className:`net-filter${oe?" active":""}`,onClick:()=>It(!oe),children:oe?"✕ Errors only":"⚠ Errors only"}),e.jsxs("span",{className:"net-count",children:[Ce.length," req"]})]}),Ce.length===0?e.jsxs("div",{className:"empty-state",children:[e.jsx("span",{className:"empty-icon",children:"🌐"}),"No network requests captured yet."]}):e.jsxs("table",{className:"net-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Method"}),e.jsx("th",{children:"URL"}),e.jsx("th",{children:"Status"}),e.jsx("th",{children:"Duration"})]})}),e.jsx("tbody",{children:Ce.map(t=>e.jsxs("tr",{className:`net-row${t.failed?" failed":""}`,children:[e.jsx("td",{children:e.jsx("span",{className:`net-method ${t.method}`,children:t.method})}),e.jsx("td",{children:e.jsx("span",{className:"net-url",title:t.url,children:t.url.replace(/^https?:\/\/[^/]+/,"")})}),e.jsx("td",{children:e.jsx("span",{className:`net-status ${Ft(t.status)}`,children:t.failed?`✕ ${t.errorText??"Failed"}`:t.status??"…"})}),e.jsx("td",{className:"net-duration",children:t.duration?`${Math.round(t.duration)}ms`:"…"})]},t.id))})]})]}),u==="report"&&e.jsxs("div",{className:"report-section",children:[e.jsxs("div",{style:{background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:10,padding:14,display:"flex",flexDirection:"column",gap:10,marginBottom:12},children:[e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center"},children:[e.jsx("span",{style:{fontWeight:700,fontSize:12,textTransform:"uppercase",letterSpacing:"0.05em",color:"var(--accent)"},children:"🧠 AI Root Cause Triage"}),e.jsx("button",{type:"button",onClick:St,disabled:ye,style:{background:"linear-gradient(135deg, var(--accent) 0%, #818cf8 100%)",color:"#fff",border:"none",borderRadius:6,padding:"5px 12px",fontWeight:600,fontSize:11,cursor:ye?"wait":"pointer"},children:ye?"⏳ Analyzing Stacktrace...":"⚡ Run Root Cause Triage"})]}),E&&e.jsxs("div",{style:{background:"var(--bg3)",border:"1px solid var(--border)",borderRadius:8,padding:12,display:"flex",flexDirection:"column",gap:8},children:[e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:8},children:[e.jsx("span",{style:{background:E.affectedComponent==="BACKEND"?"#ef4444":E.affectedComponent==="EXTERNAL_API"?"#f59e0b":"#3b82f6",color:"#fff",padding:"2px 6px",borderRadius:4,fontWeight:700,fontSize:10},children:E.affectedComponent}),e.jsx("span",{style:{fontWeight:700,fontSize:13,color:"var(--text)"},children:E.rootCause})]}),e.jsx("p",{style:{margin:0,fontSize:12,color:"var(--text2)",lineHeight:1.4},children:E.technicalSummary}),e.jsxs("div",{style:{background:"rgba(99, 102, 241, 0.1)",borderLeft:"3px solid var(--accent)",padding:"6px 10px",borderRadius:4,marginTop:4},children:[e.jsx("span",{style:{fontSize:11,fontWeight:700,color:"var(--accent)",display:"block"},children:"💡 Recommended Fix:"}),e.jsx("span",{style:{fontSize:12,color:"var(--text)"},children:E.suggestedFix})]})]})]}),e.jsx("button",{type:"button",className:`ai-btn${ge?" loading":""}`,onClick:Ut,disabled:ge||r.length===0,children:ge?"⏳ Generating…":"✨ Generate Title & Description with AI"}),e.jsx("div",{className:"settings-hint",style:{marginTop:-6},children:"AI runs server-side — no key needed here. Requires OPENAI_API_KEY in backend .env."}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{className:"form-label",children:"Title"}),e.jsx("input",{className:"form-input",placeholder:"e.g. Unable to submit checkout form",value:w,onChange:t=>Ne(t.target.value),required:!0})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{children:"Description"}),e.jsx("textarea",{rows:4,value:F,onChange:t=>Te(t.target.value)})]}),e.jsxs("div",{className:"form-group",style:{position:"relative"},children:[e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6},children:[e.jsx("label",{style:{margin:0},children:"Test Summary"}),e.jsx("button",{type:"button",onClick:Xe,style:{background:"transparent",border:"none",color:H?"#10b981":"var(--text3)",cursor:"pointer",display:"flex",alignItems:"center",gap:4,padding:0,transition:"all 0.2s"},title:"Copy steps to clipboard",children:H?e.jsxs(e.Fragment,{children:[e.jsx("svg",{style:{width:14,height:14},fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",xmlns:"http://www.w3.org/2000/svg",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2.5",d:"M5 13l4 4L19 7"})}),e.jsx("span",{style:{fontSize:11,color:"#10b981"},children:"Copied"})]}):e.jsxs(e.Fragment,{children:[e.jsx("svg",{style:{width:14,height:14},fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",xmlns:"http://www.w3.org/2000/svg",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2.5",d:"M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3"})}),e.jsx("span",{style:{fontSize:11,color:"var(--text3)"},children:"Copy"})]})})]}),e.jsx("textarea",{rows:4,value:D,onChange:t=>de(t.target.value),placeholder:"Steps for reproduction..."})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{children:"Expected Result"}),e.jsx("textarea",{rows:3,value:R,onChange:t=>it(t.target.value),placeholder:"What should have happened?"})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{children:"Actual Result"}),e.jsx("textarea",{rows:3,value:A,onChange:t=>lt(t.target.value),placeholder:"What actually happened?"})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{className:"form-label",children:"URL"}),e.jsx("input",{className:"form-input",placeholder:"e.g. https://example.com/checkout",value:$,onChange:t=>$e(t.target.value)})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{className:"form-label",children:"Test Data Details"}),e.jsx("textarea",{rows:2,className:"form-textarea",placeholder:"e.g. Username: test@test.com",value:B,onChange:t=>Ee(t.target.value)})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{className:"form-label",children:"Severity"}),e.jsx("div",{className:"severity-row",children:Object.entries(qt).map(([t,s])=>e.jsx("button",{type:"button",className:`sev-btn${N===t?" active":""}`,style:{"--sev-color":s},onClick:()=>Ie(t),children:t},t))})]}),Object.keys(d).length>0&&e.jsxs("div",{className:"form-group",children:[e.jsxs("label",{className:"form-label",children:["Screenshots (",Object.keys(d).length,") — Click star to set main image"]}),e.jsx("div",{className:"screenshots-grid",children:Object.entries(d).map(([t,s])=>{const a=Number(t),n=y===a;return e.jsxs("div",{className:`report-thumb${n?" main-selected":""}`,onClick:()=>pe(n?null:a),children:[e.jsx("img",{src:s,alt:`step ${a}`}),e.jsx("div",{className:"del-thumb",onClick:c=>{c.stopPropagation(),Je(a)},children:"✕"}),e.jsx("div",{className:"main-badge",title:n?"Remove Main Image":"Set as Main Image",children:n?"⭐":"☆"})]},a)})})]}),ie>0&&e.jsxs("div",{className:"net-attach",children:[e.jsxs("span",{className:"net-attach-label",children:["⚠ Attach ",ie," failed network requests"]}),e.jsx("button",{type:"button",className:`toggle${W?" on":""}`,onClick:()=>ct(!W)})]}),e.jsxs("div",{className:"integrations-group",children:[e.jsx("label",{className:"form-label",children:"Export Bug to Integrations"}),e.jsxs("div",{className:"integrations-grid",children:[e.jsxs("div",{className:`integration-item${K?" active":""}`,children:[e.jsxs("button",{type:"button",className:"integration-checkbox-label",onClick:()=>pt(t=>!t),children:[e.jsx("span",{children:"🎯 Jira"}),e.jsx("span",{children:K?"▼":"▶"})]}),K&&e.jsxs("div",{className:"integration-subform",children:[e.jsx("label",{className:"form-label",style:{fontSize:11,marginBottom:4},children:"Issue Type"}),e.jsxs("select",{className:"form-input",style:{fontSize:12,padding:"4px 8px"},value:he,onChange:t=>gt(t.target.value),children:[e.jsx("option",{children:"Bug"}),e.jsx("option",{children:"Task"}),e.jsx("option",{children:"Story"}),e.jsx("option",{children:"Improvement"})]}),e.jsx("button",{type:"button",className:"dispatch-btn",disabled:Oe||r.length===0||!w,onClick:Dt,children:Oe?"⏳ Dispatching...":"🎯 Dispatch to Jira"}),me&&e.jsx("div",{className:`integration-status ${me.type}`,children:me.message}),e.jsx("div",{className:"integration-hint",children:"Uses JIRA_* vars in backend .env"})]})]}),e.jsxs("div",{className:`integration-item${G?" active":""}`,children:[e.jsxs("button",{type:"button",className:"integration-checkbox-label",onClick:()=>xt(t=>!t),children:[e.jsx("span",{children:"⚡ Azure DevOps"}),e.jsx("span",{children:G?"▼":"▶"})]}),G&&e.jsxs("div",{className:"integration-subform",children:[e.jsx("label",{className:"form-label",style:{fontSize:11,marginBottom:4},children:"Work Item Type"}),e.jsxs("select",{className:"form-input",style:{fontSize:12,padding:"4px 8px"},value:xe,onChange:t=>mt(t.target.value),children:[e.jsx("option",{children:"Bug"}),e.jsx("option",{children:"Task"}),e.jsx("option",{children:"User Story"}),e.jsx("option",{children:"Feature"})]}),e.jsx("button",{type:"button",className:"dispatch-btn",disabled:We||r.length===0||!w,onClick:Pt,children:We?"⏳ Dispatching...":"⚡ Dispatch to Azure DevOps"}),fe&&e.jsx("div",{className:`integration-status ${fe.type}`,children:fe.message}),e.jsx("div",{className:"integration-hint",children:"Uses AZURE_* vars in backend .env"})]})]}),e.jsxs("div",{className:`integration-item${V?" active":""}`,children:[e.jsxs("button",{type:"button",className:"integration-checkbox-label",onClick:()=>ut(t=>!t),children:[e.jsx("span",{children:"💬 Slack"}),e.jsx("span",{children:V?"▼":"▶"})]}),V&&e.jsxs("div",{className:"integration-subform",children:[e.jsx("label",{className:"form-label",style:{fontSize:11,marginBottom:4},children:"Channel"}),e.jsxs("select",{className:"form-input",style:{fontSize:12,padding:"4px 8px"},value:J,onChange:t=>ht(t.target.value),children:[e.jsx("option",{children:"#bugs"}),e.jsx("option",{children:"#engineering"}),e.jsx("option",{children:"#support"}),e.jsx("option",{children:"#general"})]}),e.jsx("button",{type:"button",className:"dispatch-btn",disabled:Fe||r.length===0||!w,onClick:Ot,children:Fe?"⏳ Sending...":"💬 Send to Slack"}),be&&e.jsx("div",{className:`integration-status ${be.type}`,children:be.message}),e.jsx("div",{className:"integration-hint",children:"Uses SLACK_WEBHOOK_URL in backend .env"})]})]})]})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{className:"form-label",children:"Local Export Options"}),e.jsxs("div",{className:"export-actions-row",children:[e.jsx("button",{type:"button",className:"export-btn",onClick:_t,disabled:r.length===0,children:"📄 Export HTML"}),e.jsx("button",{type:"button",className:"export-btn",onClick:Wt,disabled:r.length===0,children:"📕 Export PDF"})]})]}),e.jsx("button",{type:"button",className:"submit-btn",onClick:Bt,disabled:Le||!w||r.length===0,children:Le?e.jsxs(e.Fragment,{children:[e.jsx("span",{style:{opacity:.8},children:"⏳"})," Submitting…"]}):e.jsxs(e.Fragment,{children:[e.jsx("span",{children:"🐛"})," Submit Bug Report"]})}),ze&&e.jsxs("div",{className:"error-box",children:["⚠ ",ze]})]})]})]})};class es extends o.Component{constructor(){super(...arguments);at(this,"state",{hasError:!1,error:null})}static getDerivedStateFromError(r){return{hasError:!0,error:r}}componentDidCatch(r,C){console.error("[BugBuddy SidePanel] Uncaught error:",r,C)}render(){var r;return this.state.hasError?e.jsxs("div",{style:{padding:24,background:"#090d16",color:"#f9fafb",fontFamily:'-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',height:"100vh",display:"flex",flexDirection:"column",justifyContent:"center",alignItems:"center",textAlign:"center",boxSizing:"border-box"},children:[e.jsx("div",{style:{fontSize:36,marginBottom:12},children:"⚠️"}),e.jsx("h3",{style:{margin:"0 0 8px 0",fontSize:16,color:"#ef4444"},children:"Side Panel Error"}),e.jsx("p",{style:{fontSize:12,color:"#9ca3af",maxWidth:300,marginBottom:16,lineHeight:1.4},children:((r=this.state.error)==null?void 0:r.message)||"An unexpected error occurred in the report panel."}),e.jsx("button",{onClick:()=>window.location.reload(),style:{background:"linear-gradient(135deg, #6366f1 0%, #818cf8 100%)",color:"#fff",border:"none",borderRadius:6,padding:"8px 16px",fontWeight:600,fontSize:12,cursor:"pointer"},children:"🔄 Reload Panel"})]}):this.props.children}}Jt.createRoot(document.getElementById("root")).render(e.jsx(Gt.StrictMode,{children:e.jsx(es,{children:e.jsx(Qt,{})})}));
